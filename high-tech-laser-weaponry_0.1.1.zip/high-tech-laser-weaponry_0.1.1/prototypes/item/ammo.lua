data:extend({
{

		--AMMO PROTOTYPES

	--Energy Cell (for laser-rifle)
	type = "ammo",
	name = "energy-cell",
	icon = "__high-tech-laser-weaponry__/graphics/icon_energyCell.png",
	flags = { "goes-to-main-inventory" },
	ammo_type = 
	{
		type = "projectile",
		category = "energy-ammo",
		action =
		{
			type = "direct",
			action_delivery =
			{
				type="projectile",
				projectile = "laser-cell",
				starting_speed = 1,
			}
		}
	},
	magazine_size = 12,
	subgroup = "ammo",
	order = "g[energy-ammo]-a[laser-rifle-ammo]-a[energy-cell]",
	stack_size = 100 
},
	
{	--Energy Shotgun Cell (for laser-shotgun)
	type = "ammo",
	name = "energy-shotgun-cell",
	icon = "__high-tech-laser-weaponry__/graphics/icon_energyShotgunCell.png",
	flags = { "goes-to-main-inventory" },
	ammo_type = 
	{
		type = "projectile",
		category = "energy-shotgun-ammo",
		target_type = "direction", --makes like shotgun, free fire
		action =
		{
			type = "direct",
			repeat_count = 10,
			action_delivery =
			{
				type="projectile",
				projectile = "laser-shotgun-cell",
				starting_speed = 1,
				source_effects =
          		{
            		type = "create-entity",
            		entity_name = "explosion-hit"
          		},
				direction_deviation = 0.2,
            	range_deviation = 0.3,
           		max_range = 21
			}
		}
	},
	magazine_size = 10,
	subgroup = "ammo",
	order = "g[energy-ammo]-b[laser-shotgun-ammo]-a[energy-shotgun-cell]",
	stack_size = 100 
},

{	--Energy Core (for gattling-laser)
	type = "ammo",
	name = "energy-core",
	icon = "__high-tech-laser-weaponry__/graphics/icon_energyCore.png",
	flags = { "goes-to-main-inventory" },
	ammo_type = 
	{
		type = "projectile",
		category = "energy-gattling-ammo",
		target_type = "direction", --makes like shotgun, free fire
		action =
		{
			type = "direct",
			action_delivery =
			{
				type="projectile",
				projectile = "laser-gattling-cell",
				starting_speed = 1,
				source_effects =
          		{
            		type = "create-entity",
            		entity_name = "explosion-hit"
          		},
				direction_deviation = 0.3,
            	range_deviation = 0.3,
           		max_range = 15
			}
		}
	},
	magazine_size = 100,
	subgroup = "ammo",
	order = "g[energy-ammo]-c[laser-gattling-ammo]-a[energy-core]",
	stack_size = 100 
},

{	--God Cannon Core (for god cannon, you cheater :P)
	type = "ammo",
	name = "god-cannon-cell",
	icon = "__high-tech-laser-weaponry__/graphics/icon_cheatCell.png",
	flags = { "goes-to-main-inventory" },
	ammo_type = 
	{
		type = "projectile",
		category = "cheat-ammo",
		action =
		{
			type = "direct",
			action_delivery =
			{
				type="projectile",
				projectile = "laser-god-cell",
				starting_speed = 1,
			}
		}
	},
	magazine_size = 1000,
	subgroup = "ammo",
	order = "g[energy-ammo]-d[god cannon ammo]-a[god-cell]",
	stack_size = 100 
},

{	-- God Cannon Shotgun Core (Careful with this one)
	type = "ammo",
	name = "god-cannon-shotgun-cell",
	icon = "__high-tech-laser-weaponry__/graphics/icon_cheatCellShotgun.png",
	flags = { "goes-to-main-inventory" },
	ammo_type = 
	{
		type = "projectile",
		category = "cheat-ammo-shotgun",
		target_type = "direction", --makes like shotgun, free fire
		action =
		{
			type = "direct",
			repeat_count = 17,
			action_delivery =
			{
				type="projectile",
				projectile = "laser-god-shotgun-cell",
				starting_speed = 1,
				source_effects =
          		{
            		type = "create-entity",
            		entity_name = "explosion-hit"
          		},
				direction_deviation = 0.4,
            	range_deviation = 0.3,
           		max_range = 17
			}
		}
	},
	magazine_size = 1000,
	subgroup = "ammo",
	order = "g[energy-ammo]-e[god cannon shotgun ammo]-a[god-cell-shotgun]",
	stack_size = 100 
}
})