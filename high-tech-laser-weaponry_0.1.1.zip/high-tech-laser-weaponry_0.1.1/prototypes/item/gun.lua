data:extend({
	{
	
			--Gun items, in order of tech tree
	
	
		--Laser Assault Rifle
		--mid game weapon, works like a submachine gun essentially, except it shoots lasers.
		--auto targets enemies
    	type = "gun",
    	name = "laser-rifle",
    	icon = "__high-tech-laser-weaponry__/graphics/icon_laserRifle.png",	
    	flags = { "goes-to-main-inventory" },
    	subgroup = "gun",
    	stack_size = 1,
    	order = "g[laser-guns]-a",
    	attack_parameters = 
    	{
      		type = "projectile",
      		ammo_category = "energy-ammo",
      		cooldown = 10,
      		movement_slow_down_factor = 0.3,
      		damage_modifier = 1.0,
      		projectile_creation_distance = 1.0,
      		range = 25,
      		sound = make_laser_sounds()
    	}
  	},
  	
  	{	--Laser Shotgun
  		--mid to somewhat late game weapon. Works like a normal shotgun, except it shoots lasers (12 per shot)
    	type = "gun",
    	name = "laser-shotgun",
    	icon = "__high-tech-laser-weaponry__/graphics/icon_laserShotgun.png",	
    	flags = { "goes-to-main-inventory" },
    	subgroup = "gun",
    	stack_size = 1,
    	order = "g[laser-guns]-b",
    	attack_parameters = 
    	{
      		type = "projectile",
      		ammo_category = "energy-shotgun-ammo",
      		cooldown = 40,
      		movement_slow_down_factor = 0.3,
      		damage_modifier = 1.0,
      		projectile_creation_distance = 1.0,
      		range = 21,
      		sound = make_laser_sounds()
    	}
  	},
  	
  	{	--Gattling Laser
  		--End game weapon. Shoots little blue lasers very fast. Decent range, small spread, packs a punch
  		type = "gun",
  		name = "gattling-laser",
    	icon = "__high-tech-laser-weaponry__/graphics/icon_gattlingLaser.png",	
    	flags = { "goes-to-main-inventory" },
    	subgroup = "gun",
    	stack_size = 1,
    	order = "g[laser-guns]-c",
    	attack_parameters = 
    	{
      		type = "projectile",
      		ammo_category = "energy-gattling-ammo",
      		cooldown = 3,
      		movement_slow_down_factor = 0.7,
      		damage_modifier = 1.0,
      		projectile_creation_distance = 1.0,
      		range = 20,
      		sound = make_laser_sounds()
    	}, 
  	},
  	
  	{	--You dont like biters? Just stand in the middle of their base and hold space with this baby equipped.
  		--everything will be dead in about 3 seconds.
  		--this is a cheat weapon, just for the lols. No recipe or tech available for it
    	type = "gun",
    	name = "god-cannon",
    	icon = "__high-tech-laser-weaponry__/graphics/icon_godCannon.png",	
    	flags = { "goes-to-main-inventory" },
    	subgroup = "gun",
    	stack_size = 1,
    	order = "g[laser-guns]-d",
    	attack_parameters = 
    	{
      		type = "projectile",
      		ammo_category = "cheat-ammo",
      		cooldown = 1,
      		movement_slow_down_factor = 0.0,
      		damage_modifier = 1.0,
      		projectile_creation_distance = 1.0,
      		range = 30,
      		sound = make_laser_sounds()
    	}
  	},
    {	--This fucker will eat your world. Great for clearing forests, removing your base from the map,
    	--and for wiping out anything with a health bar.
    	--this is a cheat weapon, just for the lols. No recipe or tech available for it
    	type = "gun",
    	name = "god-cannon-shotgun",
    	icon = "__high-tech-laser-weaponry__/graphics/icon_godCannonShotgun.png",	
    	flags = { "goes-to-main-inventory" },
    	subgroup = "gun",
    	stack_size = 1,
    	order = "g[laser-guns]-e",
    	attack_parameters = 
    	{
      		type = "projectile",
      		ammo_category = "cheat-ammo-shotgun",
      		
      		cooldown = 5,
      		movement_slow_down_factor = 0.0,
      		damage_modifier = 1.0,
      		projectile_creation_distance = 1.0,
      		range = 30,
      		sound = make_laser_sounds()
    	}
  	}
})