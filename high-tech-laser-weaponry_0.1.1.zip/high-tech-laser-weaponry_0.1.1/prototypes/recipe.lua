data:extend({

			--GUN RECIPES

  {	--laser-rifle Recipe
    type = "recipe",
    name = "laser assault rifle",
    enabled = "false", --disabled, unlocked by tech
    ingredients = 
    {
      {"iron-gear-wheel", 20},
      {"copper-plate", 30},
      {"steel-plate", 50},
      {"electronic-circuit", 45},
      {"advanced-circuit", 25},
      {"battery", 60}
    },
    result = "laser-rifle"
  },
  
  {	--laser-shotgun Recipe
    type = "recipe",
    name = "laser shotgun",
    enabled = "false",
    ingredients = 
    {
      {"iron-gear-wheel", 25},
      {"copper-plate", 30},
      {"steel-plate", 60},
      {"electronic-circuit", 20},
      {"advanced-circuit", 30},
      {"battery", 70}
    },
    result = "laser-shotgun"
  },
  
  {	--gatling-laser Recipe
    type = "recipe",
    name = "gattling laser",
    enabled = "false",
    ingredients = 
    {
      {"iron-gear-wheel", 40},
      {"copper-plate", 30},
      {"steel-plate", 50},
      {"electronic-circuit", 20},
      {"advanced-circuit", 15},
      {"processing-unit", 50},
      {"battery", 80},
      {"laser-rifle", 3}
    },
    result = "gattling-laser"
  },
  
  		--AMMO RECIPES
  
  {	--energy-cell (for laser-rifle) Recipe
    type = "recipe",
    name = "energy cell",
    enabled = "false",
    ingredients = 
    {
      {"battery", 3},
      {"electronic-circuit", 2}
    },
    result = "energy-cell"
  },
  
  {	--energy-core (for gattling-laser) Recipe
    type = "recipe",
    name = "energy core",
    enabled = "false",
    ingredients = 
    {
      {"copper-cable", 2},
      {"battery", 16},
      {"advanced-circuit", 2},
      {"energy-cell", 2}
    },
    result = "energy-core"
  },
  
  {	--energy-shotgun-cell (for laser-shotgun) Recipe
    type = "recipe",
    name = "energy shotgun cell",
    enabled = "false",
    ingredients = 
    {
      {"battery", 6},
      {"electronic-circuit", 2},
      {"copper-cable", 1}
    },
    result = "energy-shotgun-cell"
  },
})