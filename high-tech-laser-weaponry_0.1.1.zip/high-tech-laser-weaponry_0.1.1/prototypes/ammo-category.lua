data:extend({
	--[[
		separate ammo category required for every gun due to damage, color, and collision characteristics
	--]]
	{	--ammo for the laser assault rifle
		type = "ammo-category",
		name = "energy-ammo"
	},
	{	--ammo for the laser shotgun
		type = "ammo-category",
		name = "energy-shotgun-ammo"
	},
	{	--ammo for the gattling laser
		type = "ammo-category",
		name = "energy-gattling-ammo"
	},
	{	--ammo for the god cannon
		type = "ammo-category",
		name = "cheat-ammo"
	},
	{	--ammo for the shotgun god cannon
		type = "ammo-category",
		name = "cheat-ammo-shotgun"
	}
})