data:extend(
{

		--RECIPE UNLOCK TECHS
		--unlock all weapons and ammo added by mod

	{	--Basic Laser Weaponry
		type = "technology",
		name = "basic-laser-weaponry",
		icon = "__high-tech-laser-weaponry__/graphics/icon_laserRifle.png",
		effects =
		{	--unlocks assault rifle, shotgun, and primitive ammo types
			{
				type = "unlock-recipe",
				recipe = "laser assault rifle"
			},
			{
				type = "unlock-recipe",
				recipe = "energy cell"
			},
			{
				type = "unlock-recipe",
				recipe = "laser shotgun"
			},
			{
				type = "unlock-recipe",
				recipe = "energy shotgun cell"
			}
		},
		prerequisites = {"military-3", "advanced-electronics", "battery"},
		unit = 
		{
			count = 100,
			ingredients = 
			{
        		{"science-pack-1", 1},
        		{"science-pack-2", 1},
        		{"science-pack-3", 1}
        	},
			time = 40
		},
		order = "g[laser-tech]-a"
	},
	
	{	--Gattling Laser
		type = "technology",
		name = "gattling-laser",
		icon = "__high-tech-laser-weaponry__/graphics/icon_gattlingLaser.png",
		effects =
		{	--Unlocks Gattling Laser and its primitive ammo type
			{
				type = "unlock-recipe",
				recipe = "gattling laser"
			},
			{
				type = "unlock-recipe",
				recipe = "energy core"
			}
		},
		prerequisites = {"military-4", "basic-laser-weaponry"},
		unit = 
		{
			count = 250,
			ingredients = 
			{
				{"alien-science-pack", 1},
        		{"science-pack-1", 1},
        		{"science-pack-2", 1},
        		{"science-pack-3", 1}
        	},
			time = 50
		},
		order = "g[laser-tech]-b"
	}
})