data:extend(
{

		--AMMO UPGRADE TECHS
		--damage upgrades for all ammo types, each has 3 tiers
		--first = 10%, then 20%, then 30%, for total of 60%
		--potential damage increase



		--ENERGY CELL UPGRADES (Laser Assault Rifle)
		
  {	--Energy Cell Damage 10% (for laser-rifle)
    type = "technology",
    name = "energy-cell-damage-1",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-ammo",
        modifier = "0.1" --10% increase
      }
    },
    prerequisites = {"basic-laser-weaponry"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 45
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-a"
  },
  
  {	--Energy Cell Damage 20% (for laser-rifle)
    type = "technology",
    name = "energy-cell-damage-2",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-ammo",
        modifier = "0.2"
      }
    },
    prerequisites = {"military-4", "energy-cell-damage-1"},
    unit =
    {
      count = 250,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-b"
  },
  
  {	--Energy Cell Damage 30% (for laser-rifle)
    type = "technology",
    name = "energy-cell-damage-3",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-ammo",
        modifier = "0.3"
      }
    },
    prerequisites = {"energy-cell-damage-2"},
    unit =
    {
      count = 350,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-c"
  },
  
  		--ENERGY CORE UPGRADES (Gattling Laser)
  
  {	--Energy Core Damage 10% (for gattling-laser)
    type = "technology",
    name = "energy-core-damage-1",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCore.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-gattling-ammo",
        modifier = "0.1"
      }
    },
    prerequisites = {"gattling-laser"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 50
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-d"
  },
  
  {	--Energy Core Damage 20% (for gattling-laser)
    type = "technology",
    name = "energy-core-damage-2",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCore.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-gattling-ammo",
        modifier = "0.2"
      }
    },
    prerequisites = {"energy-core-damage-1"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-e"
  },
  
  {	--Energy Core Damage 30% (for gattling-laser)
    type = "technology",
    name = "energy-core-damage-3",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyCore.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-gattling-ammo",
        modifier = "0.3"
      }
    },
    prerequisites = {"energy-core-damage-2"},
    unit =
    {
      count = 450,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-f"
  },
  
  		--ENERGY CELL SHOTGUN UPGRADES (Laser Shotgun)
  
  {	--Energy Cell Shotgun Damage 10% (for laser-shotgun)
    type = "technology",
    name = "energy-shotgun-cell-damage-1",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyShotgunCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-shotgun-ammo",
        modifier = "0.1"
      }
    },
    prerequisites = {"basic-laser-weaponry"},
    unit =
    {
      count = 175,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 45
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-g"
  },
  
  {	--Energy Cell Shotgun Damage 20% (for laser-shotgun)
    type = "technology",
    name = "energy-shotgun-cell-damage-2",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyShotgunCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-shotgun-ammo",
        modifier = "0.2"
      }
    },
    prerequisites = {"military-4", "energy-shotgun-cell-damage-1"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-h"
  },
  
  {	--Energy Cell Shotgun Damage 30% (for laser-shotgun)
    type = "technology",
    name = "energy-shotgun-cell-damage-3",
    icon = "__high-tech-laser-weaponry__/graphics/icon_energyShotgunCell.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "energy-shotgun-ammo",
        modifier = "0.3"
      }
    },
    prerequisites = {"energy-shotgun-cell-damage-2"},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "g[laser-tech]-b[upgrades]-i"
  },
 
})