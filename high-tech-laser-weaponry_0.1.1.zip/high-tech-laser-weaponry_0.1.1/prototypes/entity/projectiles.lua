data:extend({
  {
  
  		--Projectile types for ammo
  		--separate projectile for each gun type, due to 
  		--differences in color, collision, damage
  
  	--basic laser projectile, auto targeting, for laser assault rifle
    type = "projectile",
    name = "laser-cell",
    flags = {"not-on-map"},
    acceleration = 0.005,

    action =
    {
      type = "direct",
      action_delivery = 
      {
        type="instant",
        target_effects = 
        { 
          {
            type = "create-entity",
            entity_name = "laser-bubble"
          },
          {
			type = "damage",
			damage = { amount = 20, type="laser"}
		  } 
        }
      }
    },
    light = {intensity = 0.5, size = 10},
    animation =
    {
      filename = "__high-tech-laser-weaponry__/graphics/laser-to-tint-medium.png",
      tint = {r=1.0, g=0.0, b=0.0},
      frame_count = 1,
      width = 12,
      height = 33, 
      priority = "high",
      blend_mode = "additive"
    
    },
    speed = 0.15   
  },
  
  {	--laser shotgun projectile, for direction targeting (free fire, like base game shotgun)
  	--has collision box. Red, like laser cell
    type = "projectile",
    name = "laser-shotgun-cell",
    flags = {"not-on-map"},
    acceleration = 0.005,
	collision_box = {{-0.1, -0.5}, {0.1, 0.5}},
	direction_only = true,
    action =
    {
      type = "direct",
      action_delivery = 
      {
        type="instant",
        target_effects = 
        { 
          {
            type = "create-entity",
            entity_name = "laser-bubble"
          },
          {
			type = "damage",
			damage = { amount = 8, type="laser"}
		  } 
        }
      }
    },
    light = {intensity = 0.5, size = 10},
    animation =
    {
      filename = "__high-tech-laser-weaponry__/graphics/laser-to-tint-medium.png",
      tint = {r=1.0, g=0.0, b=0.0},
      frame_count = 1,
      width = 12,
      height = 33, 
      priority = "high",
      blend_mode = "additive"
    
    },
    speed = 0.15   
  },
  
  {	--Projectile for gattling laser. Has collision, lesser damage, for direction targeting. Blue color
    type = "projectile",
    name = "laser-gattling-cell",
    flags = {"not-on-map"},
    acceleration = 0.005,
	collision_box = {{-0.1, -0.5}, {0.1, 0.5}},
	direction_only = true,
    action =
    {
      type = "direct",
      action_delivery = 
      {
        type="instant",
        target_effects = 
        { 
          {
            type = "create-entity",
            entity_name = "laser-bubble"
          },
          {
			type = "damage",
			damage = { amount = 15, type="laser"}
		  } 
        }
      }
    },
    light = {intensity = 0.5, size = 10},
    animation =
    {
      filename = "__high-tech-laser-weaponry__/graphics/laser-to-tint-medium.png",
      tint = {r=0.0, g=0.2, b=1.0},
      frame_count = 1,
      width = 12,
      height = 33, 
      priority = "high",
      blend_mode = "additive"
    
    },
    speed = 0.15   
  },
  
  {	--Projectile for cheaty god cannon, auto targetting, high damage, green color.
    type = "projectile",
    name = "laser-god-cell",
    flags = {"not-on-map"},
    acceleration = 0.005,

    action =
    {
      type = "direct",
      action_delivery = 
      {
        type="instant",
        target_effects = 
        { 
          {
            type = "create-entity",
            entity_name = "explosion-hit"
          },
          {
			type = "damage",
			damage = { amount = 30, type="laser"}
		  } 
        }
      }
    },
    light = {intensity = 0.5, size = 10},
    animation =
    {
      filename = "__high-tech-laser-weaponry__/graphics/laser-to-tint-medium.png",
      tint = {r=0.0, g=1.0, b=0.0},
      frame_count = 1,
      width = 12,
      height = 33, 
      priority = "high",
      blend_mode = "additive"
    
    },
    speed = 0.15   
  },
  
  {	--Projectile for shotgun god cannon. High damage, green color, collision box.
    type = "projectile",
    name = "laser-god-shotgun-cell",
    flags = {"not-on-map"},
    acceleration = 0.005,
	collision_box = {{-0.1, -0.5}, {0.1, 0.5}},
	direction_only = true,
    action =
    {
      type = "direct",
      action_delivery = 
      {
        type="instant",
        target_effects = 
        { 
          {
            type = "create-entity",
            entity_name = "laser-bubble"
          },
          {
			type = "damage",
			damage = { amount = 22, type="laser"}
		  } 
        }
      }
    },
    light = {intensity = 0.5, size = 10},
    animation =
    {
      filename = "__high-tech-laser-weaponry__/graphics/laser-to-tint-medium.png",
      tint = {r=0.0, g=1.0, b=0.0},
      frame_count = 1,
      width = 12,
      height = 33, 
      priority = "high",
      blend_mode = "additive"
    
    },
    speed = 0.15   
  },
})
