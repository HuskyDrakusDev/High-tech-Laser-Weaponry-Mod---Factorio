require("prototypes.ammo-category")
require("prototypes.item.gun")
require("prototypes.item.ammo")
require("prototypes.recipe")
require("prototypes.entity.projectiles")
require("prototypes.technology.technology")
require("prototypes.technology.laser-upgrades")
--Sincerely yours,
--		Husky Drakus
--
--		Go Bucks!